"""BookPilot - Personal Reading Intelligence & Recommender System"""

__version__ = "0.1"
