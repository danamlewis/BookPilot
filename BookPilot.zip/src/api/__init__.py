"""API clients for book data"""
